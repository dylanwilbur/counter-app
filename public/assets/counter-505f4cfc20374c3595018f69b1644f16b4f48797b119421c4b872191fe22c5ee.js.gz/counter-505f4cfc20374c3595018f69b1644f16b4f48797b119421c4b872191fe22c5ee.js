var myVar = setInterval(myTimer, 1000);
    
function myTimer() {
}
;
